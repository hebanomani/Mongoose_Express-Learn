var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

var Book = require('./Book.model');
var routes = require('./routes/index');
var users = require('./routes/users');

var app = express();

//mongoose connectivity
mongoose.connect('mongodb://localhost/example');

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.engine('html',require('ejs').renderFile);
app.set('view engine', 'html');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));

// Explicitly stating that I need to use bodyparser for the extended url
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);
app.use('/book',routes);

//get function
/*
app.get('/',function(req,res){
  console.log('Hello I am on index');
});
*/
//Listening whether connection is done or not
app.listen(8080, function(){
   console.log('App listening on port' +8080);
});


app.get('/books',function(req,res){
  Book.find({},function(err, books){
    //console.log(err);
    console.log(books);
    //res.send(JSON.stringify(books));
    //res.json(books);
    res.send(JSON.stringify(books));
    //res.end()
  });
});


/*
// get method for books
app.get('/books',function(req,res){
 	 console.log("All my books");
  	Book.find({})
 	 .exec(function(err,books){
     console.log("After book.find");
    if(err){
      console.log("After if err");
      console.log(err);

      res.send("Error has occured");
      console.log(err);
    }
    else {
      console.log("No error");
      console.log(books);
      res.json(books);
    }
  });

});
*/
// get method for specific book id
app.get('/books/:id',function(req,res){
  console.log('Getting book for specific id');
  var x=Book.findOne({
    _id:req.params.id
  });
  x.exec(function(err,book){
    res.send(JSON.stringify(book));
    //res.JSON(book);
  })
});
/*
//get method for specific book id
app.get('/books/:id',function(req,res){
  console.log('Getting book for specific id');
  Book.findOne({
    _id:req.params.id
  })
  .exec(function(err,book){
    if(err){
      res.send('Error has occured');
    }
    else{
      console.log(book);
      res.json(book);
    }
  });
});
*/
//post method for adding data
app.post('/book', function(req,res){
  var newBook =new Book();
  newBook.title = req.body.title;
  newBook.author = req.body.author;
  newBook.category = req.body.category;
  /*
  newBook.save({

});
res.send(newBook);
  */
  newBook.save(function(err,book){
    if(err){
      res.send("Error in saving the book");
    }
    else{
      console.log(book);
      res.send(book);
    }
  });
});

//put method for updating
app.put('/book/:id', function(req,res){
  Book.findOneAndUpdate({
    _id:req.params.id
  },
  {$set:{title: req.body.title}},
  {upsert:true},
  function(err, book){
      console.log(book);
      res.send(book);
  });
});

//delete method
app.delete('/book/:id', function(req,res){
  Book.findOneAndRemove({
    _id:req.params.id
  }, function(err,book){
          console.log(book);

  })
})


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
